package Assignment2;
import java.util.Arrays;
public class RemoveDups {
    public static void main(String[] args) {
        String[] inputArray = {"horse", "dog", "cat", "horse", "dog"};
        String[] resultArray = removeDuplicates(inputArray);
        System.out.println(Arrays.toString(resultArray));
    }
    public static String[] removeDuplicates(String[] inputArray) {
        int length = inputArray.length;
        String[] resultArray = new String[length];
        int newSize = 0;
        for (int i = 0; i < length; i++) {
            String current = inputArray[i];
            if (current != null && !contains(resultArray, current)) {
                resultArray[newSize++] = current;
            }
        }
        resultArray = Arrays.copyOf(resultArray, newSize);
        return resultArray;
    }
    public static boolean contains(String[] array, String value) {
        for (String element : array) {
            if (value.equals(element)) {
                return true;
            }
        }
        return false;
    }
}

