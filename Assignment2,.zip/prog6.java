package Assignment2;

public class prog6 {
    public static void main(String[] args) {
        // Example array
        int[] arrayOfInts = {2, -21, 3, 45, 0, 12, 18, 6, 3, 1, 0, -22};

        int minimum = arrayOfInts[0];
        for (int i = 1; i < arrayOfInts.length; i++) {
            if (arrayOfInts[i] < minimum) {
                minimum = arrayOfInts[i];
            }
        }
        System.out.println("Minimum value: " + minimum);
    }
}

