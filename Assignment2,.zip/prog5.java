package Assignment2;
import java.util.Arrays;
public class prog5 {
    public static void main(String[] args) {
        prog5 prog5 = new prog5();

        int[] arrayA = {5, 6, -4, 3, 1};
        int[] arrayB = {3, 8, 9, 11};

        int[] resultArray = prog5.combine(arrayA, arrayB);
        System.out.println("Input array a: " + Arrays.toString(arrayA));
        System.out.println("Input array b: " + Arrays.toString(arrayB));
        System.out.println("Output array: " + Arrays.toString(resultArray));
    }
    public int[] combine(int[] a, int[] b) {
        int lengthA = a.length;
        int lengthB = b.length;
        int[] resultArray = new int[lengthA + lengthB];
        System.arraycopy(a, 0, resultArray, 0, lengthA);
        System.arraycopy(b, 0, resultArray, lengthA, lengthB);

        return resultArray;
    }
}

