package Assignment2;

public class prog4 {
    public static void main(String[] args) {
        float num1 = 1.27f;
        float num2 = 3.881f;
        float num3 = 9.6f;

        int sumCasting = (int) (num1 + num2 + num3);
        int sumRounding = (int) Math.round(num1 + num2 + num3);
        System.out.println("Sum as integer: " + sumCasting);
        System.out.println("Sum as integer: " + sumRounding);
    }
}

